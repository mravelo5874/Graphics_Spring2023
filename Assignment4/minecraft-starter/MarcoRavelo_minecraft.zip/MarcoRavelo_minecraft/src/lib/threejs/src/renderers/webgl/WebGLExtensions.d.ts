export class WebGLExtensions {

	constructor( gl: WebGLRenderingContext );

	get( name: string ): any;

}
