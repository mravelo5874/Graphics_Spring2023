import { initializeCanvas } from "./App.js";

initializeCanvas();
