import { init_neural } from "./neural.js"
init_neural()
