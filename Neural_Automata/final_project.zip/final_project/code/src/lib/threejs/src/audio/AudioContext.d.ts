export const AudioContext: AudioContext;
