Final Project Submission by Marco Ravelo
Date: 4/26/2023

No collaboration was done and all the code written was by me.

Included in this directoty is all my written code within ./code, 
some images of my project used for my report within ./imgs,
and my pdf file for my final report.

Additionally, I have completed the course survey on canvas.

You can directly interact with my project by running the code as
was done for projects 2, 3, and 4. Or, you can visit my website
where it is currently being hosted: https://marcoravelo.com/.

Thanks for an awesome semester! 
It's too bad I can't make the presentation date :(