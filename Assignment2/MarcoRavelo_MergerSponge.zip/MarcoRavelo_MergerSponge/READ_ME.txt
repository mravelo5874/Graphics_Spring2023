Assignment 2 Submission by Marco Ravelo
Date: 2/22/2023

No colaboration was done and all the code writen was by me.

All parts of the assignment are complete. Plus some extra credit parts.

I implemented all required elements for this assignment including:
	- all merger sponge level generations
	- all camera controls (excluding zoom because it was not required)
	- cube and floor shaders

I also implemented an additional volumetric fractal (the jerusalem cube)
You can switch between the merger sponge and the jerusalem cube by pressing '0' on your keyboard. The current level is preserved when switching between the two.