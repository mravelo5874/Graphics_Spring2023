import { initializeCanvas } from "./App.js";
import "./tests/MengerTests.js"; /* For side effects. */

initializeCanvas();
